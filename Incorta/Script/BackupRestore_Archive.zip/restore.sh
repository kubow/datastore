#!/usr/bin/env bash

DEFAULT_BACKUPS_REPO="backups"
DEFAULT_LOGS_DIR="logs"
INCORTA="INCORTA"
SPARK="SPARK"
ZOOKEEPER="ZOOKEEPER"
CLUSTER_CONFIG_BACKUP_TYPE="CLUSTER_CONFIG_BACKUP_TYPE"
TENANT_BACKUP_TYPE="TENANT_BACKUP_TYPE"
FAILURE_MSG="Incorta Restore Operation Failed!"
SUCCESS_MSG="Incorta Restore Operation Succeeded!"
LOG_TAG_INFO="[INFO]:"
LOG_TAG_ERROR="[ERROR]:"

echo
echo

echo "*******************************************************"
echo "*  Incorta Cluster Configurations and Tenant Restore  *"
echo "*******************************************************"

echo
echo

echo "NOTE: Make sure to stop Incorta cluster before running restore operation"

echo
echo

working_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" &> /dev/null && pwd)"

until [[ "${use_default_backups_repo}" =~ ^[yYnN]$ ]]
do
  printf "Do you want to use default backups repository path which is ${working_dir}/${DEFAULT_BACKUPS_REPO}? Enter [y/Y/n/N]: "
  read -r use_default_backups_repo
done

if [[ "${use_default_backups_repo}" =~ ^[yY]$ ]]; then
  backups_repo="${working_dir}/${DEFAULT_BACKUPS_REPO}"
else
  until [[ "${valid_backups_repo}" = "true" ]]; do
    printf "\nEnter backups repository path: "
    read -r backups_repo
    if ! [[ -d "${backups_repo}" ]]; then
      echo "Input path '${backups_repo}' doesn't exist"
    else
      valid_backups_repo="true"
    fi
  done
fi

cluster_config_backups_repo="${backups_repo}/cluster-config-backups"
tenant_backups_repo="${backups_repo}/tenant-backups"

until [[ "${use_default_logs_dir}" =~ ^[yYnN]$ ]]; do
  printf "\nDo you want to use default logs directory which is ${working_dir}/${DEFAULT_BACKUPS_REPO}/${DEFAULT_LOGS_DIR}? Enter [y/Y/n/N]: "
  read -r use_default_logs_dir
done

if [[ "${use_default_logs_dir}" =~ ^[yY]$ ]]; then
  logs_dir="${working_dir}/${DEFAULT_BACKUPS_REPO}/${DEFAULT_LOGS_DIR}"
else
  until [[ "${valid_logs_dir}" = "true" ]]; do
    printf "\nEnter logs directory path: "
    read -r logs_dir
    if ! [[ -d "${logs_dir}" ]]; then
      echo "Input path '${logs_dir}' doesn't exist"
    else
      valid_logs_dir="true"
    fi
  done
fi

until [[ "${valid_email}" = "true" ]]; do
  printf "\nEnter notifications email address: "
  read -r send_to
  if [[ -z "${send_to}" ]]; then
    echo "Enter valid email address"
  else
    valid_email="true"
  fi
done

restore_date="$(date +%Y%m%d_%H%M)"
log_file="${logs_dir}/incorta-restore-${restore_date}.log"

log() {
  local message=$1
  local message_type=$2
  local stdin_print=$3
  local exit=$4
  if [[ "${stdin_print}" = "y" ]]; then
    echo "${message_type} ${message}"
  fi
  echo "[$(date)] ${message_type} ${message}" >> "${log_file}"
  if [[ "${exit}" = "y" ]]; then
    if [[ "${message_type}" = "${LOG_TAG_ERROR}" ]]; then
      send_mail "${send_to}" "${FAILURE_MSG}" "${log_file}"
      exit 1
    elif [[ "${message_type}" = "${LOG_TAG_INFO}" ]]; then
      send_mail "${send_to}" "${SUCCESS_MSG}" "${log_file}"
      exit 0
    fi
  fi
}

send_mail() {
  local email=$1
  local subject=$2
  local body_file=$3
  mail -s "${subject}" "${email}" < "${body_file}"
  if [[ "$?" -ne 0 ]]; then
    log "Failed to send mail reporting the end of restore operation please make sure to configure mail services properly" \
      "${LOG_TAG_ERROR}" "y" "n"; fi
}

get_backup() {
  local backup_name=$1
  local backup_type=$2
  local selected_valid_backup="false"
  if [[ "${backup_type}" = "${CLUSTER_CONFIG_BACKUP_TYPE}" ]]; then
    backup_sub_repo=${cluster_config_backups_repo}
  else
    backup_sub_repo=${tenant_backups_repo}
  fi
  if ! [[ -d "${backup_sub_repo}" ]]; then
    log "Backup sub repository doesn't exist" "${LOG_TAG_ERROR}" "y" "n"
    until [[ -d "${backup_dir}" ]]; do
      printf "\nEnter valid backup directory path: "
      read -r backup_dir
    done
  else
    until [[ "${selected_valid_backup}" = "true" ]]; do
      printf "\nEnter the date of the desired backup in YYYYMMDD format. Type [q/Q] to see a list of all available backups
or type [n/N] to enter specific backup directory path: "
      read -r backup_date
      if [[ "${backup_date}" =~ ^([12][0-9]{3}(0[1-9]|1[0-2])(0[1-9]|[12][0-9]|3[01]))$ ]]; then
        if [[ "$(ls "${backup_sub_repo}" | grep -i "${backup_name}" | grep -c "${backup_date}")" -ge 2 ]]; then
          printf "\nMore than one backup exists on this backup date. They are listed as follows:\n"
          ls "${backup_sub_repo}" | grep -i "${backup_name}" | grep "${backup_date}"
          printf "\nPlease choose a time from backups created on $backup_date in HHMM format: "
          read -r backup_time
          if [[ "${backup_time}" =~ ^(0[0-9]|1[0-9]|2[0-3]|[0-9])[0-5][0-9]$ ]]; then
            backup_dir="$(ls "${backup_sub_repo}" | grep -i "${backup_name}" | grep "${backup_date}_${backup_time}")"
            if [[ "$?" -ne 0 ]]; then
              log "No backups for ${backup_name} exists with the given timestamp" "${LOG_TAG_ERROR}" "y" "n"
            else
              backup_dir="${backup_sub_repo}/${backup_dir}"
              selected_valid_backup="true"
            fi
          else
            log "Input time is in incorrect format" "${LOG_TAG_ERROR}" "y" "n"
          fi
        elif [[ "$(ls "${backup_sub_repo}" | grep -i "${backup_name}" | grep -c "${backup_date}")" -eq 0 ]]; then
          log "No backups exists with that date - input date is incorrect" "${LOG_TAG_ERROR}" "y" "n"
        else
          backup_dir="${backup_sub_repo}/"$(ls "${backup_sub_repo}" | grep "${backup_name}" | grep "${backup_date}")""
          selected_valid_backup="true"
        fi
      elif [[ "${backup_date}" =~ ^[qQ]$ ]]; then
        ls "${backup_sub_repo}" | grep "${backup_name}"
      elif [[ "${backup_date}" =~ ^[nN]$ ]]; then
        printf "\nEnter valid backup directory path: "
        read -r backup_dir
        if ! [[ -d "${backup_dir}" ]]; then
          log "Input path '${backup_dir}' doesn't exist" "${LOG_TAG_ERROR}" "y" "n"
        else
          selected_valid_backup="true"
        fi
      else
        log "Input Date is in incorrect format" "${LOG_TAG_ERROR}" "y" "n"
      fi
    done
  fi
}

validate_nodes() {
  local cluster_type=$1
  local num_nodes=$2
  for (( i = 1; i <= "${num_nodes}"; i++ )); do
    node_hostname="${cluster_type}_NODE_${i}_HOSTNAME" && node_hostname=${!node_hostname}
    node_username="${cluster_type}_NODE_${i}_USERNAME" && node_username=${!node_username}
    node_password="${cluster_type}_NODE_${i}_PASSWORD" && node_password=${!node_password}
    node_key_path="${cluster_type}_NODE_${i}_KEY_PATH" && node_key_path=${!node_key_path}
    node_installation_home="${cluster_type}_NODE_${i}_HOME" && node_installation_home=${!node_installation_home}
    cluster_type_formatted="${cluster_type:0:1}$(tr '[:upper:]' '[:lower:]' <<< ${cluster_type:1:${#cluster_type}})"
    if [[ -z "${node_hostname}" ]]; then
      log "Make sure to specify hostname for ${cluster_type_formatted} node #${i} in the parameters file" \
        "${LOG_TAG_ERROR}" "y" "y"
    fi
    if [[ -z "${node_username}" ]]; then
      log "Make sure to specify username for ${cluster_type_formatted} node #${i} in the parameters file" \
        "${LOG_TAG_ERROR}" "y" "y"
    fi
    if [[ -z "${node_installation_home}" ]]; then
      log "Make sure to specify installation home for ${cluster_type_formatted} node #${i} in the parameters file" \
        "${LOG_TAG_ERROR}" "y" "y"
    fi
  done
}

validate_cluster() {
  if ! [[ "${NUM_INCORTA_NODES}" =~ ^0$|^[1-9][0-9]*$ ]]; then
    log "Make sure to specify valid number of Incorta nodes in cluster" "${LOG_TAG_ERROR}" "y" "y"
  fi
  if ! [[ "${NUM_SPARK_NODES}" =~ ^0$|^[1-9][0-9]*$ ]]; then
    log "Make sure to specify valid number of Spark nodes in cluster" "${LOG_TAG_ERROR}" "y" "y"
  fi
  if ! [[ "${NUM_ZOOKEEPER_NODES}" =~ ^0$|^[1-9][0-9]*$ ]]; then
    log "Make sure to specify valid number of Zookeeper nodes in cluster" "${LOG_TAG_ERROR}" "y" "y"
  fi
  if [[ -z "${CMC_NODE_HOSTNAME}" ]]; then
    log "Make sure to specify hostname for CMC node in the parameters file" "${LOG_TAG_ERROR}" "y" "y"
  fi
  if [[ -z "${CMC_NODE_USERNAME}" ]]; then
    log "Make sure to specify username for CMC node in the parameters file" "${LOG_TAG_ERROR}" "y" "y"
  fi
  if [[ -z "${CMC_HOME}" ]]; then
    log "Make sure to specify installation home for CMC node in the parameters file" $LOG_TAG_ERROR "y" "y"
  fi
  validate_nodes "${INCORTA}" "${NUM_INCORTA_NODES}"
  validate_nodes "${SPARK}" "${NUM_SPARK_NODES}"
  validate_nodes "${ZOOKEEPER}" "${NUM_ZOOKEEPER_NODES}"
}

remote_copy() {
  local password=$1
  local key_path=$2
  local source_path=$4
  local destination_path=$5
  if ! [[ -z "${key_path}" ]]; then
    rsync -avqze "ssh -i $key_path" "${source_path}" "${destination_path}" &> /dev/null
  elif ! [[ -z "${password}" ]]; then
    expect -c "
      spawn rsync -avqz ${source_path} ${destination_path}
      expect {
        -nocase \"password\" {
          send \"${password}\r\"
          exp_continue
        }
      }
      lassign [wait] pid spawnid os_error_flag value
      if {\${os_error_flag} == 0} {
        exit \${value}
      } else {
        exit -1
      }
    " &> /dev/null
  else
    rsync -avqz "${source_path}" "${destination_path}" &> /dev/null
  fi
  local rsync_exit_code=$?
  if [[ "${rsync_exit_code}" -eq 23 || "${rsync_exit_code}" -eq 24 ]]; then
    log "Copying failed due to nonexistent source files - rsync command exit code: ${rsync_exit_code}" \
      "${LOG_TAG_ERROR}" "y" "n"
  elif [[ "${rsync_exit_code}" -eq 255 ]]; then
    log "Copying failed due to error in SSH connection to node - rsync command exit code: ${rsync_exit_code}" \
      "${LOG_TAG_ERROR}" "y" "n"
  elif [[ "${rsync_exit_code}" -eq 12 ]]; then
    log "Copying failed due to error in rsync protocol data stream - rsync command exit code: ${rsync_exit_code}" \
      "${LOG_TAG_ERROR}" "y" "n"
  elif [[ "${rsync_exit_code}" -eq 30 ]]; then
    log "Copying failed due to timeout in data send/receive - rsync command exit code: ${rsync_exit_code}" \
      "${LOG_TAG_ERROR}" "y" "n"
  elif [[ "${rsync_exit_code}" -eq -1 ]]; then
    log "Copying failed due to OS error - rsync command exit code: ${rsync_exit_code}" "${LOG_TAG_ERROR}" "y" "n"
  elif [[ "${rsync_exit_code}" -ne 0 ]]; then
    log "Copying failed due to unknown error - rsync command exit code: ${rsync_exit_code}" "${LOG_TAG_ERROR}" "y" "n"
  fi
  return "${rsync_exit_code}"
}

restore_cmc_node_config() {
  local backup_dir=$1
  local cmc_restore_success="true"
  log "Restoring CMC node configuration files" "${LOG_TAG_INFO}" "y" "n"
  remote_copy "${CMC_NODE_PASSWORD}" "${CMC_NODE_KEY_PATH}" "" "${backup_dir}/cmcData/" \
    "${CMC_NODE_USERNAME}@${CMC_NODE_HOSTNAME}:${CMC_HOME}/cmcData"
  if [[ "$?" -ne 0 ]]; then log "Failed to restore cmcData directory to CMC node" "${LOG_TAG_ERROR}" "y" "n"
    cmc_restore_success="false"; fi
  remote_copy "${CMC_NODE_PASSWORD}" "${CMC_NODE_KEY_PATH}" "" "${backup_dir}/conf/" \
    "${CMC_NODE_USERNAME}@${CMC_NODE_HOSTNAME}:${CMC_HOME}/conf"
  if [[ "$?" -ne 0 ]]; then log "Failed to restore conf directory to CMC node" "${LOG_TAG_ERROR}" "y" "n"
    cmc_restore_success="false"; fi
  remote_copy "${CMC_NODE_PASSWORD}" "${CMC_NODE_KEY_PATH}" "" "${backup_dir}/incorta/" \
    "${CMC_NODE_USERNAME}@${CMC_NODE_HOSTNAME}:${CMC_HOME}/incorta"
  if [[ "$?" -ne 0 ]]; then log "Failed to restore incorta directory to CMC node" "${LOG_TAG_ERROR}" "y" "n"
    cmc_restore_success="false"; fi
  if [[ "${cmc_restore_success}" = "false" ]]; then
    log "Failed to restore CMC configuration files" "${LOG_TAG_ERROR}" "y" "n"
    successful_restore="false"
  fi
}

get_node_services_from_backup() {
  local node_backup_services=()
  while IFS= read -r line; do
    node_backup_services+=("$(echo "${line}" | tr -d ' ')")
  done<"services.index"
  node_backup_analytics_services=()
  node_backup_loader_services=()
  for node_backup_service in "${node_backup_services[@]}"; do
    local service=()
    IFS='=' read -a service <<< "${node_backup_service}"
    if [[ "${service[0]}" =~ ^analyticsService$ ]]; then
      node_backup_analytics_services+=("${service[1]}")
    elif [[ "${service[0]}" =~ ^loaderService$ ]]; then
      node_backup_loader_services+=("${service[1]}")
    fi
  done
}

get_services_on_restore_node() {
  local hostname=$1
  local username=$2
  local password=$3
  local key_path=$4
  local incorta_node_home=$5
  local node_name=$6
  mkdir "temp" && cd "temp"
  remote_copy "${password}" "${key_path}" "" "${username}@${hostname}:${incorta_node_home}/services/services.index" "./"
  if [[ "$?" -ne 0 ]]; then log "[incorta_${node_name}] Failed to retrieve services.index file" "${LOG_TAG_ERROR}" "y" "n"
    successful_restore="false"; return 1; fi
  local node_services=()
  while IFS= read -r line; do
    node_services+=("$(echo "${line}" | tr -d ' ')")
  done <"services.index"
  rm "services.index"
  cd .. && rm -r "temp"
  node_analytics_services=()
  node_loader_services=()
  for node_service in "${node_services[@]}"; do
    local service=()
    IFS='=' read -a service <<< "${node_service}"
    if [[ "${service[0]}" =~ ^.*[aA]nalytic.*$ ]]; then
      node_analytics_services+=("${service[1]}")
    elif [[ "${service[0]}" =~ ^.*[lL]oader.*$ ]]; then
      node_loader_services+=("${service[1]}")
    fi
  done
}

restore_node_service_config() {
  local hostname=$1
  local username=$2
  local password=$3
  local key_path=$4
  local incorta_node_home=$5
  local node_name=$6
  local source_service=$7
  local target_service=$8
  remote_copy "${password}" "${key_path}" "" "${source_service}/conf/" \
    "${username}@${hostname}:${incorta_node_home}/services/${target_service}/conf"
  if [[ "$?" -ne 0 ]]; then
    log "[incorta_${node_name}] Failed to restore conf directory from service ${source_service} to service ${target_service}" \
      "${LOG_TAG_ERROR}" "y" "n"; return 1; fi
  remote_copy "${password}" "${key_path}" "" "${source_service}/incorta/" \
    "${username}@${hostname}:${incorta_node_home}/services/${target_service}/incorta"
  if [[ "$?" -ne 0 ]]; then
    log "[incorta_${node_name}] Failed to restore incorta directory from service ${source_service} to service ${target_service}" \
      "${LOG_TAG_ERROR}" "y" "n"; return 1; fi
}

restore_node_agent_config() {
  local hostname=$1
  local username=$2
  local password=$3
  local key_path=$4
  local incorta_node_home=$5
  local node_name=$6
  remote_copy "${password}" "${key_path}" "" "node-agent-config/" "${username}@${hostname}:${incorta_node_home}/nodeAgent"
  if [[ "$?" -ne 0 ]]; then log "[incorta_${node_name}] Failed to restore nodeAgent.cfg file" "${LOG_TAG_ERROR}" "y" "n"
    return 1; fi
}

restore_incorta_node_config() {
  local hostname=$1
  local username=$2
  local password=$3
  local key_path=$4
  local incorta_node_home=$5
  local node_name=$6
  cd "${node_name}"
  if [[ "${restore_node_properties}" =~ ^[yY]$ ]]; then
    log "[incorta_${node_name}] Restoring node.properties file" "${LOG_TAG_INFO}" "y" "n"
    remote_copy "${password}" "${key_path}" "" "node.properties" "${username}@${hostname}:${incorta_node_home}"
  fi
  if [[ "${restore_analytics}" =~ ^[yY]$ ]] || [[ "${restore_loader}" =~ ^[yY]$ ]]; then
    log "[incorta_${node_name}] Restoring services configuration files" "${LOG_TAG_INFO}" "y" "n"
    get_node_services_from_backup
    get_services_on_restore_node "${hostname}" "${username}" "${password}" "${key_path}" "${incorta_node_home}" "${node_name}"
    if [[ "$?" -eq 0 ]]; then
      if [[ "${restore_analytics}" =~ ^[yY]$ ]]; then
        if [[ "${#node_analytics_services[@]}" -ge "${#node_backup_analytics_services[@]}" ]]; then
          analytics_services_count=${#node_backup_analytics_services[@]}
        else
          analytics_services_count=${#node_analytics_services[@]}
        fi
        for (( j=0; j < "${analytics_services_count}"; j++ )); do
          log "[incorta_${node_name}] Restoring analytics service '${node_backup_analytics_services[${j}]}' configuration files to '${node_analytics_services[${j}]}'" \
            "${LOG_TAG_INFO}" "y" "n"
          restore_node_service_config "${hostname}" "${username}" "${password}" "${key_path}" "${incorta_node_home}" \
            "${node_name}" "${node_backup_analytics_services[${j}]}" "${node_analytics_services[${j}]}"
          if [[ "$?" -ne 0 ]]; then log "[incorta_${node_name}] Failed to restore analytics service configuration files" \
            "${LOG_TAG_ERROR}" "y" "n"; successful_restore="false"; fi
        done
      fi
      if [[ "${restore_loader}" =~ ^[yY]$ ]]; then
        if [[ "${#node_loader_services[@]}" -ge "${#node_backup_loader_services[@]}" ]]; then
          loader_services_count=${#node_backup_loader_services[@]}
        else
          loader_services_count=${#node_loader_services[@]}
        fi
        for (( j=0; j < "${loader_services_count}"; j++ )); do
          log "[incorta_${node_name}] Restoring loader service '${node_backup_loader_services[$j]}' configuration files to '${node_loader_services[$j]}'" \
            "${LOG_TAG_INFO}" "y" "n"
          restore_node_service_config "${hostname}" "${username}" "${password}" "${key_path}" "${incorta_node_home}" \
            "${node_name}" "${node_backup_loader_services[${j}]}" "${node_loader_services[${j}]}"
          if [[ "$?" -ne 0 ]]; then log "[incorta_${node_name}] Failed to restore loader service configuration files" \
            "${LOG_TAG_ERROR}" "y" "n"; successful_restore="false"; fi
        done
      fi
    else
      log "[incorta_${node_name}] Failed to restore services configuration files" "${LOG_TAG_ERROR}" "y" "n"
      successful_restore="false"
    fi
  fi
  if [[ "${restore_nodeAgent}" =~ ^[yY]$ ]]; then
    log "[incorta_${node_name}] Restoring nodeAgent configuration files" "${LOG_TAG_INFO}" "y" "n"
    restore_node_agent_config "${hostname}" "${username}" "${password}" "${key_path}" "${incorta_node_home}" "${node_name}"
    if [[ "$?" -ne 0 ]]; then log "[incorta_${node_name}] Failed to restore nodeAgent configuration files" \
      "${LOG_TAG_ERROR}" "y" "n"; successful_restore="false";fi
  fi
  cd ..
}

restore_spark_node_config() {
  local hostname=$1
  local username=$2
  local password=$3
  local key_path=$4
  local spark_home=$5
  local node_name=$6
  log "[spark_${node_name}] Restoring Spark configuration files" "${LOG_TAG_INFO}" "y" "n"
  remote_copy "${password}" "${key_path}" "" "${node_name}/conf/" "${username}@${hostname}:${spark_home}/conf"
  if [[ "$?" -ne 0 ]]; then
    log "[spark_${node_name}] Failed to restore conf directory" "${LOG_TAG_ERROR}" "y" "n"
    log "[spark_${node_name}] Failed to restore Spark node configuration files" "${LOG_TAG_ERROR}" "y" "n"
    successful_restore="false"
  fi
}

restore_zookeeper_node_config() {
  local hostname=$1
  local username=$2
  local password=$3
  local key_path=$4
  local zookeeper_home=$5
  local node_name=$6
  log "[zookeeper_${node_name}] Restoring Zookeeper configuration files" "${LOG_TAG_INFO}" "y" "n"
  remote_copy "${password}" "${key_path}" "" "${node_name}/conf/" "${username}@${hostname}:${zookeeper_home}/conf"
  if [[ "$?" -ne 0 ]]; then
    log "[zookeeper_${node_name}] Failed to restore conf directory" "${LOG_TAG_ERROR}" "y" "n"
    log "[zookeeper_${node_name}] Failed to restore Zookeeper node configuration files" "${LOG_TAG_ERROR}" "y" "n"
    successful_restore="false"
  fi
}

restore_cluster_config() {
  local cluster_type=$1
  local num_nodes=$2
  local backup_dir=$3
  cd "${backup_dir}"
  for (( i = 1; i <= "${num_nodes}"; i++ )); do
    node_hostname="${cluster_type}_NODE_${i}_HOSTNAME" && node_hostname=${!node_hostname}
    node_username="${cluster_type}_NODE_${i}_USERNAME" && node_username=${!node_username}
    node_password="${cluster_type}_NODE_${i}_PASSWORD" && node_password=${!node_password}
    node_key_path="${cluster_type}_NODE_${i}_KEY_PATH" && node_key_path=${!node_key_path}
    node_installation_home="${cluster_type}_NODE_${i}_HOME" && node_installation_home=${!node_installation_home}
    cluster_type_formatted="$(tr '[:upper:]' '[:lower:]' <<< ${cluster_type:0:${#cluster_type}})"
    node_name="node_${i}"
    if ! [[ -d "${node_name}" ]]; then
      log "[${cluster_type_formatted}_node_${i}] Failed to restore configuration files - backup directory ${backup_dir}/${node_name} doesn't exist" \
        "${LOG_TAG_ERROR}" "y" "n"
      continue
    fi
    if [[ "${cluster_type}" = "${INCORTA}" ]]; then
      restore_incorta_node_config "${node_hostname}" "${node_username}" "${node_password}" "${node_key_path}" \
        "${node_installation_home}" "${node_name}"
    elif [[ "${cluster_type}" = "${SPARK}" ]]; then
      restore_spark_node_config "${node_hostname}" "${node_username}" "${node_password}" "${node_key_path}" \
        "${node_installation_home}" "${node_name}"
    elif [[ "${cluster_type}" = "${ZOOKEEPER}" ]]; then
      restore_zookeeper_node_config "${node_hostname}" "${node_username}" "${node_password}" "${node_key_path}" \
        "${node_installation_home}" "${node_name}"
    fi
  done
}

restore_tenant_files() {
  local tenant_name=$1
  local files_type=$2
  local tenant_backup_dir=$3
  local tenant_dir=$4
  log "Restoring tenant '${tenant_name}' ${files_type} files" "${LOG_TAG_INFO}" "y" "n"
  rm -rf "${tenant_dir}/${files_type}"
  unzip "${tenant_backup_dir}/${files_type}.zip" -d "${tenant_dir}" &> /dev/null
}

echo
log "Log file path: ${log_file}" "${LOG_TAG_INFO}" "y" "n"

successful_restore="true"

until [[ "${restore_cluster_config}" =~ ^[yYnN]$ ]]; do
  printf "\nDo you want to restore cluster configuration files? Enter [y/Y/n/N]: "
  read -r restore_cluster_config
done

if [[ "${restore_cluster_config}" =~ ^[yY] ]]; then
  until ! [[ -z "${cluster_name}" ]]; do
    printf "\nEnter cluster name: "
    read -r cluster_name
  done
  get_backup "${cluster_name}" "${CLUSTER_CONFIG_BACKUP_TYPE}"
  echo
  cluster_config_backup_dir=${backup_dir}
  log "Cluster '${cluster_name}' configuration files backup directory path: ${cluster_config_backup_dir}" \
    "${LOG_TAG_INFO}" "y" "n"
  if [[ -f "${working_dir}/restore.parameters" ]]; then
    log "restore.parameters file exists" "${LOG_TAG_INFO}" "n" "n"
    until [[ "${use_restore_parameters}" =~ ^[yYnN]$ ]]; do
      printf "\nDo you want to use restore.parameters file for cluster configuration files restore operation? Enter [y/Y/n/N]: "
      read -r use_restore_parameters
    done
    echo
    if [[ "${use_restore_parameters}" =~ [yY] ]]; then
      log "Reading provided restore.parameters file contents" "${LOG_TAG_INFO}" "y" "n"
      source "${working_dir}/restore.parameters"
    else
      log "Reading already backed up backup.parameters file contents" "${LOG_TAG_INFO}" "y" "n"
      source "${cluster_config_backup_dir}/backup.parameters"
    fi
  else
    log "restore.parameters file doesn't exist" "${LOG_TAG_INFO}" "n" "n"
    log "Reading already backed up backup.parameters file contents" "${LOG_TAG_INFO}" "y" "n"
    source "${cluster_config_backup_dir}/backup.parameters"
  fi
  validate_cluster
  log "Asking user for what files to be restored for ${cluster_name} cluster" "${LOG_TAG_INFO}" "n" "n"
  until [[ "${restore_all_cluster_config}" =~ ^[yYnN]$ ]]; do
    printf "\nDo you want to perform full restore for ${cluster_name} cluster? Enter [y/Y/n/N]: "
    read -r restore_all_cluster_config
  done
  if [[ "${restore_all_cluster_config}" =~ ^[yY]$ ]]; then
    if [[ -d "${cluster_config_backup_dir}/cmc-config" ]]; then
      restore_cmc="y"
    fi
    if [[ -d "${cluster_config_backup_dir}/nodes-config" ]]; then
      restore_analytics="y" && restore_loader="y" && restore_nodeAgent="y" && restore_node_properties="y"
    fi
    if [[ -d "${cluster_config_backup_dir}/spark-config" ]]; then
      restore_spark="y"
    fi
    if [[ -d "${cluster_config_backup_dir}/zookeeper-config" ]]; then
      restore_zookeeper="y"
    fi
  elif [[ "${restore_all_cluster_config}" =~ ^[nN]$ ]]; then
    if [[ -d "${cluster_config_backup_dir}/cmc-config" ]]; then
      until [[ "${restore_cmc}" =~ ^[yYnN]$ ]]; do
        printf "\nDo you want to restore CMC configuration files? Enter [y/Y/n/N]: "
        read -r restore_cmc
      done
    fi
    if [[ -d "${cluster_config_backup_dir}/nodes-config" ]]; then
      until [[ "${restore_node_properties}" =~ ^[yYnN]$ ]]; do
        printf "\nDo you want to restore node.properties file for each node in the cluster? Enter [y/Y/n/N]: "
        read -r restore_node_properties
      done
      until [[ "${restore_analytics}" =~ ^[yYnN]$ ]]; do
        printf "\nDo you want to restore analytics service configuration files for each node in the cluster? Enter [y/Y/n/N]: "
        read -r restore_analytics
      done
      until [[ "${restore_loader}" =~ ^[yYnN]$ ]]; do
        printf "\nDo you want to restore loader service configuration files for each node in the cluster? Enter [y/Y/n/N]: "
        read -r restore_loader
      done
      until [[ "${restore_nodeAgent}" =~ ^[yYnN]$ ]]; do
        printf "\nDo you want to restore nodeAgent configuration files for each node in the cluster? Enter [y/Y/n/N]: "
        read -r restore_nodeAgent
      done
    fi
    if [[ -d "${cluster_config_backup_dir}/spark-config" ]]; then
      until [[ "${restore_spark}" =~ ^[yYnN]$ ]]; do
        printf "\nDo you want to restore Spark configuration files for each node in the cluster? Enter [y/Y/n/N]: "
        read -r restore_spark
      done
    fi
    if [[ -d "${cluster_config_backup_dir}/zookeeper-config" ]]; then
      until [[ "${restore_zookeeper}" =~ ^[yYnN]$ ]]; do
        printf "\nDo you want to restore Zookeeper configuration files for each node in the cluster? Enter [y/Y/n/N]: "
        read -r restore_zookeeper
      done
    fi
  fi
fi

until [[ "${restore_tenant}" =~ ^[yYnN]$ ]]; do
  printf "\nDo you want to restore tenant? Enter [y/Y/n/N]: "
  read -r restore_tenant
done

if [[ "${restore_tenant}" =~ ^[yY]$ ]]; then
  if [[ "${restore_cluster_config}" =~ ^[nN]$ ]]; then
    until ! [[ -z "${cluster_name}" ]]; do
      printf "\nEnter cluster name: "
      read -r cluster_name
    done
  fi
  until ! [[ -z "${tenant_name}" ]]; do
    printf "\nEnter tenant name: "
    read -r tenant_name
  done
  get_backup "${tenant_name}" "${TENANT_BACKUP_TYPE}"
  echo
  tenant_backup_dir=${backup_dir}
  log "Tenant '${tenant_name}' backup directory path: ${tenant_backup_dir}" "${LOG_TAG_INFO}" "y" "n"
  until [[ "${valid_tmt_home}" = "true" ]]; do
    printf "\nEnter TMT home path: "
    read -r tmt_home
    if ! [[ -d "${tmt_home}" ]]; then
      log "Input path '${tmt_home}' doesn't exist" "${LOG_TAG_ERROR}" "y" "n"
    else
      valid_tmt_home="true"
    fi
  done
  log "Asking user for what files to be restored for ${tenant_name} tenant" "${LOG_TAG_INFO}" "n" "n"
  until [[ "${restore_all_tenant}" =~ ^[yYnN]$ ]]; do
    printf "\nDo you want to perform full restore for $tenant_name tenant? Enter [y/Y/n/N]: "
    read -r restore_all_tenant
  done
  if [[ "${restore_all_tenant}" =~ ^[yY]$ ]]; then
    if [[ -f "${tenant_backup_dir}/${tenant_name}.zip" ]]; then
      restore_metadata="y"
    fi
    if [[ -f "${tenant_backup_dir}/data.zip" ]]; then
      restore_data="y"
    fi
    if [[ -f "${tenant_backup_dir}/parquet.zip" ]]; then
      restore_parquet="y"
    fi
    if [[ -f "${tenant_backup_dir}/snapshots.zip" ]]; then
      restore_snapshots="y"
    fi
    if [[ -f "${tenant_backup_dir}/compacted.zip" ]]; then
      restore_compacted="y"
    fi
    if [[ -d "${tenant_backup_dir}/time-log" ]]; then
      restore_schemas_time_log="y"
    fi
  elif [[ "${restore_all_tenant}" =~ ^[nN]$ ]]; then
    if [[ -f "${tenant_backup_dir}/${tenant_name}.zip" ]]; then
      until [[ "${restore_metadata}" =~ ^[yYnN]$ ]]; do
        printf "\nDo you want to restore tenant metadata? Enter [y/Y/n/N]: "
        read -r restore_metadata
      done
    fi
    if [[ -f "${tenant_backup_dir}/data.zip" ]]; then
      until [[ "${restore_data}" =~ ^[yYnN]$ ]]; do
        printf "\nDo you want to restore tenant data files? Enter [y/Y/n/N]: "
        read -r restore_data
      done
    fi
    if [[ -f "${tenant_backup_dir}/parquet.zip" ]]; then
      until [[ "${restore_parquet}" =~ ^[yYnN]$ ]]; do
        printf "\nDo you want to restore tenant parquet files? Enter [y/Y/n/N]: "
        read -r restore_parquet
      done
    fi
    if [[ -f "${tenant_backup_dir}/snapshots.zip" ]]; then
      until [[ "${restore_snapshots}" =~ ^[yYnN]$ ]]; do
        printf "\nDo you want to restore tenant snapshot files? Enter [y/Y/n/N]: "
        read -r restore_snapshots
      done
    fi
    if [[ -f "${tenant_backup_dir}/compacted.zip" ]]; then
      until [[ "${restore_compacted}" =~ ^[yYnN]$ ]]; do
        printf "\nDo you want to restore tenant compacted parquet files? Enter [y/Y/n/N]: "
        read -r restore_compacted
      done
    fi
    if [[ -d "${tenant_backup_dir}/time-log" ]]; then
      until [[ "${restore_schemas_time_log}" =~ ^[yYnN]$ ]]; do
        printf "\nDo you want to restore schemas time log files? Enter [y/Y/n/N]: "
        read -r restore_schemas_time_log
      done
    fi
  fi
fi

if [[ "${restore_metadata}" =~ ^[yY] ]]; then
  until [[ "${valid_metadata_backup_dir}" = "true" ]]; do
    printf "\nEnter valid backup directory path for tenant metadata since tenant will be removed: "
    read -r metadata_backup_dir
    if [[ -z $metadata_backup_dir ]]
    then
      log "Input path '${metadata_backup_dir}' doesn't exist" "${LOG_TAG_ERROR}" "y" "n"
    else
      valid_metadata_backup_dir="true"
    fi
  done
fi

echo

if [[ "${restore_cluster_config}" =~ ^[yY] ]]; then
  if [[ "${restore_cmc}" =~ ^[yY]$ ]]; then
    restore_cmc_node_config "${cluster_config_backup_dir}/cmc-config"
  fi
  if [[ "${restore_analytics}" =~ ^[yY]$ ]] || [[ "${restore_loader}" =~ ^[yY]$ ]] ||
      [[ "${restore_nodeAgent}" =~ ^[yY]$ ]]; then
    restore_cluster_config "${INCORTA}" "${NUM_INCORTA_NODES}" "${cluster_config_backup_dir}/nodes-config"
  fi
  if [[ "${restore_spark}" =~ ^[yY]$ ]]; then
    restore_cluster_config "${SPARK}" "${NUM_SPARK_NODES}" "${cluster_config_backup_dir}/spark-config"
  fi
  if [[ $restore_zookeeper =~ ^[yY]$ ]]; then
    restore_cluster_config "${ZOOKEEPER}" "${NUM_ZOOKEEPER_NODES}" "${cluster_config_backup_dir}/zookeeper-config"
  fi
fi

if [[ "${restore_tenant}" =~ ^[yY]$ ]]; then
  if [[ "${restore_metadata}" =~ ^[yY]$ ]]; then
    cd "${tmt_home}"
    log "Backing up tenant metadata before restoring" "${LOG_TAG_INFO}" "y" "n"
    ./tmt.sh -ex "${tenant_name}" "${tenant_name}_${restore_date}.zip" -clnm "${cluster_name}" &> /dev/null
    mv "${tenant_name}_${restore_date}.zip" "${metadata_backup_dir}"
    mv "${tenant_name}_${restore_date}.properties" $metadata_backup_dir
    log "Restoring tenant metadata requires removal of existent tenant using TMT shell script" "${LOG_TAG_INFO}" "y" "n"
    ./tmt.sh -r "${tenant_name}" -clnm "${cluster_name}"
    ./tmt.sh -i "${tenant_backup_dir}/${tenant_name}.zip" -clnm "${cluster_name}"
  fi
  if [[ "${restore_data}" =~ ^[yY]$ ]] || [[ "${restore_parquet}" =~ ^[yY]$ ]] ||
      [[ "${restore_snapshots}" =~ ^[yY]$ ]] || [[ "${restore_compacted}" =~ ^[yY]$ ]] ||
      [[ "${restore_schemas_time_log}" =~ ^[yY]$ ]]; then
    log "Getting tenant directory path" "${LOG_TAG_INFO}" "n" "n"
    cd "${tmt_home}"
    if ./tmt.sh -clnm "${cluster_name}" -l | grep -ic --quiet "${tenant_name}"; then
      tenant_dir="$(./tmt.sh -clnm "${cluster_name}" -lc "${tenant_name}" | grep "path=" | sed -e "s/^path=//")"
      log "Validating tenant directory" "${LOG_TAG_INFO}" "n" "n"
      if ! [[ -d "${tenant_dir}" ]]; then
        log "Tenant '${tenant_name}' directory '${tenant_dir}' doesn't exist" "${LOG_TAG_ERROR}" "y" "y"
      fi
    else
      log "Tenant '${tenant_name}' doesn't exist or cluster '${cluster_name}' doesn't exist" "${LOG_TAG_ERROR}" "y" "n"
    fi
  fi
  if [[ "${restore_data}" =~ ^[yY]$ ]]; then
    restore_tenant_files "${tenant_name}" "data" "${tenant_backup_dir}" "${tenant_dir}"
  fi
  if [[ "${restore_parquet}" =~ ^[yY]$ ]]; then
    restore_tenant_files "${tenant_name}" "parquet" "${tenant_backup_dir}" "${tenant_dir}"
  fi
  if [[ "${restore_snapshots}" =~ ^[yY]$ ]]; then
    restore_tenant_files "${tenant_name}" "snapshots" "${tenant_backup_dir}" "${tenant_dir}"
  fi
  if [[ "${restore_compacted}" =~ ^[yY]$ ]]; then
    restore_tenant_files "${tenant_name}" "compacted" "${tenant_backup_dir}" "${tenant_dir}"
  fi
  if [[ "${restore_schemas_time_log}" =~ ^[yY]$ ]]; then
    log "Restoring tenant '${tenant_name}' schemas time log files" "${LOG_TAG_INFO}" "y" "n"
    rsync -avqz "${tenant_backup_dir}/time-log/" "${tenant_dir}"
  fi
fi

echo
echo

if [[ "${restore_cmc}" =~ ^[yY]$ ]] || [[ "${restore_analytics}" =~ ^[yY]$ ]] || [[ "${restore_loader}" =~ ^[yY]$ ]] ||
    [[ "${restore_nodeAgent}" =~ ^[yY]$ ]] || [[ "${restore_spark}" =~ ^[yY]$ ]] || [[ "${restore_zookeeper}" =~ ^[yY]$ ]]; then
  echo "NOTE: If you are restoring cluster configuration files into a different cluster other than the one already backed up,
Make sure to edit these files (or directories) inorder not to break cluster configurations:"
  if [[ "${restore_cmc}" =~ ^[yY]$ ]]; then
    echo "- CMC configuration files:"
    echo "--- CMC_HOME/cmcData/*"
    echo "--- CMC_HOME/conf/catalina.properties"
  fi
  if [[ "${restore_node_properties}" =~ ^[yY]$ ]] || [[ "${restore_analytics}" =~ ^[yY]$ ]] || [[ "${restore_loader}" =~ ^[yY]$ ]]; then
    echo "- Incorta node configuration files:"
    if [[ "${restore_node_properties}" =~ ^[yY]$ ]]; then
      echo "--- INCORTA_NODE_HOME/node.properties"
    fi
    if [[ "${restore_analytics}" =~ ^[yY]$ ]] || [[ "${restore_loader}" =~ ^[yY]$ ]]; then
      echo "--- INCORTA_NODE_HOME/conf/catalina.properties"
      echo "--- INCORTA_NODE_HOME/incorta/service.properties"
    fi
    if [[ "${restore_nodeAgent}" =~ ^[yY]$ ]]; then
      echo "--- INCORTA_NODE_HOME/nodeAgent/nodeAgent.cfg"
    fi
  fi
  if [[ "${restore_spark}" =~ ^[yY]$ ]]; then
    echo "- Spark node configuration files:"
    echo "--- SPARK_NODE_HOME/conf/spark-env.sh"
    echo "--- SPARK_NODE_HOME/conf/slaves (if exists)"
  fi
  if [[ "${restore_zookeeper}" =~ ^[yY]$ ]]; then
    echo "- Zookeeper node configuration files:"
    echo "--- ZOOKEEPER_NODE_HOME/conf/zoo.cfg"
  fi
fi

echo
echo

if [[ ${successful_restore} = "true" ]]; then
  log "Restore operation finished successfully" "${LOG_TAG_INFO}" "y" "y"
else
  log "Restore operation failed" "${LOG_TAG_ERROR}" "y" "y"
fi
