#!/usr/bin/env bash

source backup.parameters

DEFAULT_BACKUPS_REPO="backups"
DEFAULT_LOGS_DIR="logs"
INCORTA="INCORTA"
SPARK="SPARK"
ZOOKEEPER="ZOOKEEPER"
CLUSTER_CONFIG_BACKUP_TYPE="CLUSTER_CONFIG_BACKUP_TYPE"
TENANT_BACKUP_TYPE="TENANT_BACKUP_TYPE"
FAILURE_MSG="Incorta Backup Operation Failed!"
SUCCESS_MSG="Incorta Backup Operation Succeeded!"
LOG_TAG_INFO="[INFO]:"
LOG_TAG_ERROR="[ERROR]:"

echo
echo

echo "******************************************************"
echo "*  Incorta Cluster Configurations and Tenant Backup  *"
echo "******************************************************"

echo
echo

echo "NOTE: Make sure to stop Incorta cluster before running backup operation"

echo
echo

working_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" &> /dev/null && pwd)"

if [[ -z "${BACKUPS_REPO}" ]]; then
  BACKUPS_REPO="${working_dir}/${DEFAULT_BACKUPS_REPO}"
fi

if ! [[ -d "${BACKUPS_REPO}" ]]; then
  mkdir "${BACKUPS_REPO}"
fi

if [[ -z "${LOGS_DIR}" ]]; then
  LOGS_DIR="${working_dir}/${DEFAULT_BACKUPS_REPO}/${DEFAULT_LOGS_DIR}"
fi

if ! [[ -d "${LOGS_DIR}" ]]; then
  mkdir "${LOGS_DIR}"
fi

BACKUP_DATE="$(date +%Y%m%d_%H%M)"
LOG_FILE="${LOGS_DIR}/incorta-backup-${BACKUP_DATE}.log"

log() {
  local message=$1
  local message_type=$2
  local stdin_print=$3
  local exit=$4
  if [[ "${stdin_print}" = "y" ]]; then
    echo "${message_type} ${message}"
  fi
  echo "[$(date)] ${message_type} ${message}" >> "${LOG_FILE}"
  if [[ "${exit}" = "y" ]]; then
    if [[ "${message_type}" = "${LOG_TAG_ERROR}" ]]; then
      send_mail "${SEND_TO}" "${FAILURE_MSG}" "${LOG_FILE}"
      exit 1
    elif [[ "${message_type}" = "${LOG_TAG_INFO}" ]]; then
      send_mail "${SEND_TO}" "${SUCCESS_MSG}" "${LOG_FILE}"
      exit 0
    fi
  fi
}

send_mail() {
  local email=$1
  local subject=$2
  local body_file=$3
  mail -s "${subject}" "${email}" < "${body_file}"
  if [[ "$?" -ne 0 ]]; then
    log "Failed to send mail reporting the end of backup operation please make sure to configure mail services properly" \
      "${LOG_TAG_ERROR}" "y" "n"; fi
}

validate_nodes() {
  local cluster_type=$1
  local num_nodes=$2
  for (( i = 1; i <= "${num_nodes}"; i++ )); do
    node_hostname="${cluster_type}_NODE_${i}_HOSTNAME" && node_hostname=${!node_hostname}
    node_username="${cluster_type}_NODE_${i}_USERNAME" && node_username=${!node_username}
    node_password="${cluster_type}_NODE_${i}_PASSWORD" && node_password=${!node_password}
    node_key_path="${cluster_type}_NODE_${i}_KEY_PATH" && node_key_path=${!node_key_path}
    node_installation_home="${cluster_type}_NODE_${i}_HOME" && node_installation_home=${!node_installation_home}
    cluster_type_formatted="${cluster_type:0:1}$(tr '[:upper:]' '[:lower:]' <<< ${cluster_type:1:${#cluster_type}})"
    if [[ -z "${node_hostname}" ]]; then
      log "Make sure to specify hostname for ${cluster_type_formatted} node #${i} in the parameters file" \
        "${LOG_TAG_ERROR}" "y" "y"
    fi
    if [[ -z "${node_username}" ]]; then
      log "Make sure to specify username for ${cluster_type_formatted} node #${i} in the parameters file" \
        "${LOG_TAG_ERROR}" "y" "y"
    fi
    if [[ -z "${node_installation_home}" ]]; then
      log "Make sure to specify installation home for ${cluster_type_formatted} node #${i} in the parameters file" \
        "${LOG_TAG_ERROR}" "y" "y"
    fi
  done
}

log "Log file path: ${LOG_FILE}" "${LOG_TAG_INFO}" "y" "n"

log "Validating backup.parameters file" "${LOG_TAG_INFO}" "y" "n"

if [[ -z "${BACKUPS_REPO_MAX_SIZE}" || ! "${BACKUPS_REPO_MAX_SIZE}" =~ ^[1-9][0-9]*$ ]]; then
  log "Make sure to specify valid value for maximum size of backups repository in the parameters file" \
    "${LOG_TAG_ERROR}" "y" "y"
fi
if [[ -z "${RETENTION_PERIOD}" || ! "${RETENTION_PERIOD}" =~ ^[1-9][0-9]*$ ]]; then
  log "Make sure to specify valid value for retention period in the parameters file" "${LOG_TAG_ERROR}" "y" "y"
fi
if [[ -z "${SEND_TO}" ]]; then
  log "Make sure to specify notifications email address in the parameters file" "${LOG_TAG_ERROR}" "y" "y"
fi
if [[ -z "${CLUSTER_NAME}" ]]; then
  log "Make sure to specify cluster name in the parameters file" "${LOG_TAG_ERROR}" "y" "y"
fi
if ! [[ "${BACKUP_CLUSTER_CONFIG}" =~ ^[yY]$|^\s*$ ]]; then
  log "Make sure to specify valid value for BACKUP_CLUSTER_CONFIG in the parameters file" "${LOG_TAG_ERROR}" "y" "y"
else
  if ! [[ "${NUM_INCORTA_NODES}" =~ ^0$|^[1-9][0-9]*$ ]]; then
    log "Make sure to specify valid number of Incorta nodes in cluster" "${LOG_TAG_ERROR}" "y" "y"
  fi
  if ! [[ "${NUM_SPARK_NODES}" =~ ^0$|^[1-9][0-9]*$ ]]; then
    log "Make sure to specify valid number of Spark nodes in cluster" "${LOG_TAG_ERROR}" "y" "y"
  fi
  if ! [[ "${NUM_ZOOKEEPER_NODES}" =~ ^0$|^[1-9][0-9]*$ ]]; then
    log "Make sure to specify valid number of Zookeeper nodes in cluster" "${LOG_TAG_ERROR}" "y" "y"
  fi
  if [[ -z "${CMC_NODE_HOSTNAME}" ]]; then
    log "Make sure to specify hostname for CMC node in the parameters file" "${LOG_TAG_ERROR}" "y" "y"
  fi
  if [[ -z "${CMC_NODE_USERNAME}" ]]; then
    log "Make sure to specify username for CMC node in the parameters file" "${LOG_TAG_ERROR}" "y" "y"
  fi
  if [[ -z "${CMC_HOME}" ]]; then
    log "Make sure to specify installation home for CMC node in the parameters file" "${LOG_TAG_ERROR}" "y" "y"
  fi
  validate_nodes "${INCORTA}" "${NUM_INCORTA_NODES}"
  validate_nodes "${SPARK}" "${NUM_SPARK_NODES}"
  validate_nodes "${ZOOKEEPER}" "${NUM_ZOOKEEPER_NODES}"
fi
if ! [[ "${BACKUP_TENANT_METADATA}" =~ ^[yY]$|^\s*$ ]]; then
  log "Make sure to specify valid value for BACKUP_TENANT_METADATA in the parameters file" "${LOG_TAG_ERROR}" "y" "y"
fi
if ! [[ "${BACKUP_DATA}" =~ ^[yY]$|^\s*$ ]]; then
  log "Make sure to specify valid value for BACKUP_DATA in the parameters file" "${LOG_TAG_ERROR}" "y" "y"
fi
if ! [[ "${BACKUP_PARQUET}" =~ ^[yY]$|^\s*$ ]]; then
  log "Make sure to specify valid value for BACKUP_PARQUET in the parameters file" "${LOG_TAG_ERROR}" "y" "y"
fi
if ! [[ "${BACKUP_SNAPSHOTS}" =~ ^[yY]$|^\s*$ ]]; then
  log "Make sure to specify valid value for BACKUP_SNAPSHOTS in the parameters file" "${LOG_TAG_ERROR}" "y" "y"
fi
if ! [[ "${BACKUP_COMPACTED}" =~ ^[yY]$|^\s*$ ]]; then
  log "Make sure to specify valid value for BACKUP_COMPACTED in the parameters file" "${LOG_TAG_ERROR}" "y" "y"
fi
if ! [[ "${BACKUP_SCHEMAS_TIME_LOG}" =~ ^[yY]$|^\s*$ ]]; then
  log "Make sure to specify valid value for BACKUP_SCHEMAS_TIME_LOG in the parameters file" "${LOG_TAG_ERROR}" "y" "y"
fi
if [[ "${BACKUP_TENANT_METADATA}" =~ ^[yY]$ ]] || [[ "${BACKUP_DATA}" =~ ^[yY]$ ]] ||
    [[ "${BACKUP_PARQUET}" =~ ^[yY]$ ]] || [[ "${BACKUP_SNAPSHOTS}" =~ ^[yY]$ ]] ||
    [[ "${BACKUP_COMPACTED}" =~ ^[yY]$ ]] || [[ "${BACKUP_SCHEMAS_TIME_LOG}" =~ ^[yY]$ ]]; then
  if [[ -z "${TENANT_NAME}" ]]; then
    log "Make sure to specify tenant name in the parameters file" "${LOG_TAG_ERROR}" "y" "y"
  fi
  if [[ -z "${TMT_HOME}" || ! -d "${TMT_HOME}" ]]; then
    log "Make sure to specify valid TMT home path on CMC node in the parameters file" "${LOG_TAG_ERROR}" "y" "y"
  fi
fi
log "Finished backup.parameters file validation" "${LOG_TAG_INFO}" "y" "n"

apply_backup_retention_rule() {
  local backup_repo_path=$1
  local old_backups="$(find "${backup_repo_path}" -name '*backup*' -type d -ctime +"${RETENTION_PERIOD}")"
  local old_logs="$(find "${LOGS_DIR}" -name '*backup*' -type f -ctime +"${RETENTION_PERIOD}")"
  if ! [[ -z "${old_backups}" ]]; then
      log "Found backups older than the retention period specified in the parameters file" "${LOG_TAG_INFO}" "n" "n"
      echo
      echo "These backups are older than the retention period specified in the parameters file:"
      echo "${old_backups}"
      echo
      until [[ "${remove_old}" =~ ^[yYnN]$ ]]
      do
        printf "\nDo you want to remove these backups and their log files? Enter [y/Y/n/N]: "
        read -r remove_old
      done
      if [[ "${remove_old}" =~ ^[yY]$ ]]; then
        echo "${old_backups}" | xargs rm -rf
        echo "${old_logs}" | xargs rm -rf
      fi
  fi
}

is_backup_feasible() {
  local backup_name=$1
  local backup_type=$2
  if [[ "${backup_type}" = "${CLUSTER_CONFIG_BACKUP_TYPE}" ]]; then
    backup_repo_path=${CLUSTER_CONFIG_BACKUP_REPO}
  else
    backup_repo_path=${TENANT_BACKUP_REPO}
  fi
  local similar_old_backups="$(du -kd 1 "${backup_repo_path}" | grep "${backup_name}")"
  if ! [[ -z "${similar_old_backups}" ]]; then
    local mean_size="$(echo "${similar_old_backups}" | awk '{sum += $1; n++;} END {print sum/n;}')"
    if [[ "$((${BACKUPS_REPO_MAX_SIZE} - $(du -sk | grep -o '[0-9]*')))" -lt "${mean_size}" ]]; then
      log "No enough space to complete the backup operation. Similar backups consume about ${mean_size} kilobytes. Free some space then re-run the script" \
        "${LOG_TAG_ERROR}" "y" "y"
    fi
  fi
}

remote_copy() {
  local password=$1
  local key_path=$2
  local exclusion=$3
  local source_path=$4
  local destination_path=$5
  if ! [[ -z "${key_path}" ]]; then
    if ! [[ -z "${exclusion}" ]]; then
      rsync -avqze "ssh -i ${key_path}" "${source_path}" "${destination_path}" --exclude "${exclusion}" &> /dev/null
    else
      rsync -avqze "ssh -i $key_path" "${source_path}" "${destination_path}" &> /dev/null
    fi
  elif ! [[ -z "${password}" ]]; then
    if ! [[ -z "${exclusion}" ]]; then
      rsync_command="rsync -avqz ${source_path} ${destination_path} --exclude ${exclusion}"
    else
      rsync_command="rsync -avqz ${source_path} ${destination_path}"
    fi
    expect -c "
      spawn ${rsync_command}
      expect {
        -nocase \"password\" {
          send \"${password}\r\"
          exp_continue
        }
      }
      lassign [wait] pid spawnid os_error_flag value
      if {\${os_error_flag} == 0} {
        exit \${value}
      } else {
        exit -1
      }
    " &> /dev/null
  else
    if ! [[ -z "${exclusion}" ]]; then
      rsync -avqz "${source_path}" "${destination_path}" --exclude "${exclusion}" &> /dev/null
    else
      rsync -avqz "${source_path}" "${destination_path}" &> /dev/null
    fi
  fi
  local rsync_exit_code=$?
  if [[ "${rsync_exit_code}" -eq 23 || "${rsync_exit_code}" -eq 24 ]]; then
    log "Copying failed due to nonexistent source files - rsync command exit code: ${rsync_exit_code}" \
      "${LOG_TAG_ERROR}" "y" "n"
  elif [[ "${rsync_exit_code}" -eq 255 ]]; then
    log "Copying failed due to error in SSH connection to node - rsync command exit code: ${rsync_exit_code}" \
      "${LOG_TAG_ERROR}" "y" "n"
  elif [[ "${rsync_exit_code}" -eq 12 ]]; then
    log "Copying failed due to error in rsync protocol data stream - rsync command exit code: ${rsync_exit_code}" \
      "${LOG_TAG_ERROR}" "y" "n"
  elif [[ "${rsync_exit_code}" -eq 30 ]]; then
    log "Copying failed due to timeout in data send/receive - rsync command exit code: ${rsync_exit_code}" \
      "${LOG_TAG_ERROR}" "y" "n"
  elif [[ "${rsync_exit_code}" -eq -1 ]]; then
    log "Copying failed due to OS error - rsync command exit code: ${rsync_exit_code}" "${LOG_TAG_ERROR}" "y" "n"
  elif [[ "${rsync_exit_code}" -ne 0 ]]; then
    log "Copying failed due to unknown error - rsync command exit code: ${rsync_exit_code}" "${LOG_TAG_ERROR}" "y" "n"
  fi
  return "${rsync_exit_code}"
}

backup_cmc_node_config() {
  local cmc_backup_success="true"
  log "Backing up CMC node configuration files" "${LOG_TAG_INFO}" "y" "n"
  remote_copy "${CMC_NODE_PASSWORD}" "${CMC_NODE_KEY_PATH}" "" \
    "${CMC_NODE_USERNAME}@${CMC_NODE_HOSTNAME}:${CMC_HOME}/cmcData" "cmc-config"
  if [[ "$?" -ne 0 ]]; then
    log "Failed to backup cmcData directory from CMC node" "${LOG_TAG_ERROR}" "y" "n"
    cmc_backup_success="false"
    successful_backup="false"
  fi
  remote_copy "${CMC_NODE_PASSWORD}" "${CMC_NODE_KEY_PATH}" "" \
    "${CMC_NODE_USERNAME}@${CMC_NODE_HOSTNAME}:${CMC_HOME}/conf" "cmc-config"
  if [[ "$?" -ne 0 ]]; then
    log "Failed to backup conf directory from CMC node" "${LOG_TAG_ERROR}" "y" "n"
    cmc_backup_success="false"
    successful_backup="false"
  fi
  remote_copy "${CMC_NODE_PASSWORD}" "${CMC_NODE_KEY_PATH}" "*.template" \
    "${CMC_NODE_USERNAME}@${CMC_NODE_HOSTNAME}:${CMC_HOME}/incorta" "cmc-config"
  if [[ "$?" -ne 0 ]]; then log "Failed to backup incorta directory from CMC node" "${LOG_TAG_ERROR}" "y" "n"
    cmc_backup_success="false"; successful_backup="false"; fi
  if [[ "${cmc_backup_success}" = "false" ]]; then log "Failed to backup CMC configuration files" \
    "${LOG_TAG_ERROR}" "y" "n"; successful_backup="false"; fi
}

get_node_services() {
  local hostname=$1
  local username=$2
  local password=$3
  local key_path=$4
  local incorta_node_home=$5
  local node_name=$6
  remote_copy "${password}" "${key_path}" "" "${username}@${hostname}:${incorta_node_home}/services/services.index" "./"
  if [[ "$?" -ne 0 ]]; then log "[incorta_${node_name}] Failed to retrieve services.index file" \
    "${LOG_TAG_ERROR}" "y" "n"; successful_backup="false"; return 1; fi
  local node_services=()
  while IFS= read -r line; do
    node_services+=("$(echo "${line}" | tr -d ' ')")
  done <"services.index"
  rm "services.index"
  node_analytics_services=()
  node_loader_services=()
  for node_service in "${node_services[@]}"; do
    local service=()
    IFS='=' read -a service <<< "${node_service}"
    if [[ "${service[0]}" =~ ^.*[aA]nalytic.*$ ]]; then
      node_analytics_services+=("${service[1]}")
    elif [[ "${service[0]}" =~ ^.*[lL]oader.*$ ]]; then
      node_loader_services+=("${service[1]}")
    fi
  done
}

backup_incorta_service_config() {
  local hostname=$1
  local username=$2
  local password=$3
  local key_path=$4
  local incorta_node_home=$5
  local node_name=$6
  local service=$7
  remote_copy "${password}" "${key_path}" "" \
    "${username}@${hostname}:${incorta_node_home}/services/$service/conf" "${node_name}/${service}"
  if [[ "$?" -ne 0 ]]; then log "[incorta_${node_name}] Failed to backup conf directory" \
    "${LOG_TAG_ERROR}" "y" "n"; successful_backup="false"; return 1; fi
  remote_copy "${password}" "${key_path}" "*.template" \
    "${username}@${hostname}:${incorta_node_home}/services/${service}/incorta" "${node_name}/${service}"
  if [[ "$?" -ne 0 ]]; then log "[incorta_${node_name}] Failed to backup incorta directory" \
    "${LOG_TAG_ERROR}" "y" "n"; successful_backup="false"; return 1; fi
}

backup_incorta_node_agent_config() {
  local hostname=$1
  local username=$2
  local password=$3
  local key_path=$4
  local incorta_node_home=$5
  local node_name=$6
  remote_copy "${password}" "${key_path}" "" \
    "${username}@${hostname}:${incorta_node_home}/nodeAgent/nodeAgent.cfg" "${node_name}/node-agent-config/"
  if [[ "$?" -ne 0 ]]; then log "[incorta_${node_name}] Failed to backup nodeAgent.cfg file" "${LOG_TAG_ERROR}" "y" "n"
    successful_backup="false"; return 1; fi
}

backup_incorta_node_config() {
  local hostname=$1
  local username=$2
  local password=$3
  local key_path=$4
  local incorta_node_home=$5
  local node_name=$6
  log "[incorta_${node_name}] Backing up node.properties file" "${LOG_TAG_INFO}" "y" "n"
  remote_copy "${password}" "${key_path}" "" "${username}@${hostname}:${incorta_node_home}/node.properties" "${node_name}/"
  if [[ "$?" -ne 0 ]]; then log "[incorta_${node_name}] Failed to backup node.properties" "${LOG_TAG_ERROR}" "y" "n"; \
    successful_backup="false"; fi
  log "[incorta_${node_name}] Backing up services configuration files" "${LOG_TAG_INFO}" "y" "n"
  get_node_services "${hostname}" "${username}" "${password}" "${key_path}" "${incorta_node_home}" "${node_name}"
  if [[ "$?" -eq 0 ]]; then
    for analytics_service in "${node_analytics_services[@]}"; do
      echo "analyticsService=${analytics_service}" | tee -a "${node_name}/services.index" &> /dev/null
      log "[incorta_${node_name}] Backing up analytics service '${analytics_service}' configuration files" \
        "${LOG_TAG_INFO}" "y" "n"
      backup_incorta_service_config "${hostname}" "${username}" "${password}" "${key_path}" "${incorta_node_home}" \
        "${node_name}" "${analytics_service}"
      if [[ "$?" -ne 0 ]]; then log "[incorta_${node_name}] Failed to backup analytics service configuration files" \
        "${LOG_TAG_ERROR}" "y" "n"; successful_backup="false"; fi
    done
    for loader_service in "${node_loader_services[@]}"; do
      echo "loaderService=${loader_service}" | tee -a "${node_name}/services.index" &> /dev/null
      log "[incorta_${node_name}] Backing up loader service '${loader_service}' configuration files" \
        "${LOG_TAG_INFO}" "y" "n"
      backup_incorta_service_config "${hostname}" "${username}" "${password}" "${key_path}" "${incorta_node_home}" \
        "${node_name}" "${loader_service}"
      if [[ "$?" -ne 0 ]]; then log "[incorta_$node_name] Failed to backup loader service configuration files" \
        "${LOG_TAG_ERROR}" "y" "n"; successful_backup="false"; fi
    done
  else
    log "[incorta_${node_name}] Failed to backup services configuration files" "${LOG_TAG_ERROR}" "y" "n"
    successful_backup="false"
  fi
  log "[incorta_${node_name}] Backing up nodeAgent configuration files" "${LOG_TAG_INFO}" "y" "n"
  backup_incorta_node_agent_config "${hostname}" "${username}" "${password}" "${key_path}" \
    "${incorta_node_home}" "${node_name}"
  if [[ "$?" -ne 0 ]]; then log "[incorta_${node_name}] Failed to backup nodeAgent configuration files" \
    "${LOG_TAG_ERROR}" "y" "n"; successful_backup="false"; fi
}

backup_spark_node_config() {
  local hostname=$1
  local username=$2
  local password=$3
  local key_path=$4
  local spark_home=$5
  local node_name=$6
  log "[spark_${node_name}] Backing up Spark configuration files" "${LOG_TAG_INFO}" "y" "n"
  remote_copy "${password}" "${key_path}" "*.template" "${username}@${hostname}:${spark_home}/conf" "${node_name}"
  if [[ "$?" -ne 0 ]]; then
    log "[spark_${node_name}] Failed to backup conf directory" "${LOG_TAG_ERROR}" "y" "n"
    log "[spark_${node_name}] Failed to backup Spark node configuration files" "${LOG_TAG_ERROR}" "y" "n"
    successful_backup="false"
  fi
}

backup_zookeeper_node_config() {
  local hostname=$1
  local username=$2
  local password=$3
  local key_path=$4
  local zookeeper_home=$5
  local node_name=$6
  log "[zookeeper_${node_name}] Backing up Zookeeper configuration files" "${LOG_TAG_INFO}" "y" "n"
  remote_copy "${password}" "${key_path}" "*.template" "${username}@${hostname}:${zookeeper_home}/conf" "${node_name}"
  if [[ "$?" -ne 0 ]]; then
    log "[zookeeper_${node_name}] Failed to backup conf directory" "${LOG_TAG_ERROR}" "y" "n"
    log "[zookeeper_${node_name}] Failed to backup Zookeeper node configuration files" "${LOG_TAG_ERROR}" "y" "n"
    successful_backup="false"
  fi
}

backup_cluster_config() {
  local cluster_type=$1
  local num_nodes=$2
  for (( i = 1; i <= "${num_nodes}"; i++ )); do
    node_hostname="${cluster_type}_NODE_${i}_HOSTNAME" && node_hostname=${!node_hostname}
    node_username="${cluster_type}_NODE_${i}_USERNAME" && node_username=${!node_username}
    node_password="${cluster_type}_NODE_${i}_PASSWORD" && node_password=${!node_password}
    node_key_path="${cluster_type}_NODE_${i}_KEY_PATH" && node_key_path=${!node_key_path}
    node_installation_home="${cluster_type}_NODE_${i}_HOME" && node_installation_home=${!node_installation_home}
    node_name="node_${i}"
    if [[ "${cluster_type}" = "${INCORTA}" ]]; then
      backup_incorta_node_config "${node_hostname}" "${node_username}" "${node_password}" "${node_key_path}" \
        "${node_installation_home}" "${node_name}"
    elif [[ "${cluster_type}" = "${SPARK}" ]]; then
      backup_spark_node_config "${node_hostname}" "${node_username}" "${node_password}" "${node_key_path}" \
        "${node_installation_home}" "${node_name}"
    elif [[ "${cluster_type}" = "${ZOOKEEPER}" ]]; then
      backup_zookeeper_node_config "${node_hostname}" "${node_username}" "${node_password}" "${node_key_path}" \
        "${node_installation_home}" "${node_name}"
    fi
  done
}

backup_tenant_files() {
  local files_type=$1
  log "Backing up tenant '${TENANT_NAME}' $files_type files" "${LOG_TAG_INFO}" "y" "n"
  if [[ ! -d "${files_type}" ]]; then
    log "Failed to backup tenant '${TENANT_NAME}' ${files_type} files - ${files_type} directory doesn't exist" \
      "${LOG_TAG_ERROR}" "y" "n"
    successful_backup="false"
  else
    zip -rq "${files_type}.zip" "${files_type}"
    mv "${TENANT_DIR}/${files_type}.zip" "${TENANT_BACKUP_DIR}"
  fi
}

CLUSTER_CONFIG_BACKUP_REPO="${BACKUPS_REPO}/cluster-config-backups"
TENANT_BACKUP_REPO="${BACKUPS_REPO}/tenant-backups"

if ! [[ -d "${CLUSTER_CONFIG_BACKUP_REPO}" ]]; then
  mkdir "${CLUSTER_CONFIG_BACKUP_REPO}"
fi

if ! [[ -d "${TENANT_BACKUP_REPO}" ]]; then
  mkdir "${TENANT_BACKUP_REPO}"
fi

successful_backup="true"

log "Checking for retention period" "${LOG_TAG_INFO}" "n" "n"
apply_backup_retention_rule "${CLUSTER_CONFIG_BACKUP_REPO}"
apply_backup_retention_rule "${TENANT_BACKUP_REPO}"

if [[ "${BACKUP_CLUSTER_CONFIG}" =~ ^[yY]$ ]]; then
  log "Checking for feasibility of backing up cluster configuration" "${LOG_TAG_INFO}" "n" "n"
  is_backup_feasible "${CLUSTER_NAME}" "${CLUSTER_CONFIG_BACKUP_TYPE}"
  cd "${CLUSTER_CONFIG_BACKUP_REPO}"
  CLUSTER_CONFIG_BACKUP_DIR="${CLUSTER_CONFIG_BACKUP_REPO}/${CLUSTER_NAME}-backup-${BACKUP_DATE}"
  mkdir "${CLUSTER_CONFIG_BACKUP_DIR}" && cd "${CLUSTER_CONFIG_BACKUP_DIR}"
  log "Cluster '${CLUSTER_NAME}' configuration files backup directory path: ${CLUSTER_CONFIG_BACKUP_DIR}" \
    "${LOG_TAG_INFO}" "y" "n"
  log "Starting backup of cluster '${CLUSTER_NAME}' configuration files" "${LOG_TAG_INFO}" "y" "n"
  backup_cmc_node_config
  mkdir "nodes-config" && cd "nodes-config" && backup_cluster_config "${INCORTA}" "${NUM_INCORTA_NODES}"
  cd .. && mkdir "spark-config" && cd "spark-config" && backup_cluster_config "${SPARK}" "${NUM_SPARK_NODES}"
  cd .. && mkdir "zookeeper-config" && cd "zookeeper-config" && backup_cluster_config "${ZOOKEEPER}" \
    "${NUM_ZOOKEEPER_NODES}"
  cp "${working_dir}/backup.parameters" "${CLUSTER_CONFIG_BACKUP_DIR}"
fi

if [[ "${BACKUP_TENANT_METADATA}" =~ ^[yY]$ ]] || [[ "${BACKUP_DATA}" =~ ^[yY]$ ]] ||
    [[ "${BACKUP_PARQUET}" =~ ^[yY]$ ]] || [[ "${BACKUP_SNAPSHOTS}" =~ ^[yY]$ ]] ||
    [[ "${BACKUP_SNAPSHOTS}" =~ ^[yY]$ ]] || [[ "${BACKUP_COMPACTED}" =~ ^[yY]$ ]] ||
    [[ "${BACKUP_SCHEMAS_TIME_LOG}" =~ ^[yY]$ ]]; then
  log "Checking for feasibility of backing up tenant" "${LOG_TAG_INFO}" "n" "n"
  is_backup_feasible "${TENANT_NAME}" "${TENANT_BACKUP_TYPE}"
  log "Validating incorta installation directory on backup node" "${LOG_TAG_INFO}" "n" "n"
  if [[ ! -d "${TMT_HOME}" ]]; then
    log "Incorta TMT home directory '${TMT_HOME}' doesn't exist on backup node" "${LOG_TAG_ERROR}" "y" "y"
    successful_backup="false"
  fi
  log "Validating tenant and cluster names" "${LOG_TAG_INFO}" "n" "n"
  cd "${TMT_HOME}"
  if ./tmt.sh -clnm "${CLUSTER_NAME}" -l | grep -ic --quiet "${TENANT_NAME}"; then
      TENANT_DIR="$(./tmt.sh -clnm "${CLUSTER_NAME}" -lc "${TENANT_NAME}" | grep "path=" | sed -e "s/^path=//")"
  else
    log "Tenant '${TENANT_NAME}' doesn't exist or cluster '${CLUSTER_NAME}' doesn't exist" "${LOG_TAG_ERROR}" "y" "y"
    successful_backup="false"
  fi
  log "Validating tenant directory" "${LOG_TAG_INFO}" "n" "n"
  if ! [[ -d "${TENANT_DIR}" ]]; then
    log "Tenant '${TENANT_NAME}' directory '${TENANT_DIR}' doesn't exist" "${LOG_TAG_ERROR}" "y" "y"
    successful_backup="false"
  fi
  cd "${TENANT_BACKUP_REPO}"
  TENANT_BACKUP_DIR="${TENANT_BACKUP_REPO}/"${TENANT_NAME}"-backup-${BACKUP_DATE}"
  mkdir "${TENANT_BACKUP_DIR}"
  log "Tenant '${TENANT_NAME}' backup directory path: ${TENANT_BACKUP_DIR}" "${LOG_TAG_INFO}" "y" "n"
  log "Starting backup of tenant '${TENANT_NAME}'" "${LOG_TAG_INFO}" "y" "n"
  if [[ "${BACKUP_TENANT_METADATA}" =~ ^[yY]$ ]]; then
    log "Backing up tenant '${TENANT_NAME}' metadata" "${LOG_TAG_INFO}" "y" "n"
    cd "${TMT_HOME}"
    ./tmt.sh -ex "${TENANT_NAME}" "${TENANT_NAME}.zip" -clnm "${CLUSTER_NAME}" &> /dev/null
    mv "${TENANT_NAME}.zip" "${TENANT_BACKUP_DIR}"
    mv "${TENANT_NAME}.properties" "${TENANT_BACKUP_DIR}"
  fi
  cd "${TENANT_DIR}"
  if [[ "${BACKUP_DATA}" =~ ^[yY]$ ]]; then
    backup_tenant_files "data"
  fi
  if [[ "${BACKUP_PARQUET}" =~ ^[yY]$ ]]; then
    backup_tenant_files "parquet"
  fi
  if [[ "${BACKUP_SNAPSHOTS}" =~ ^[yY]$ ]]; then
    backup_tenant_files "snapshots"
  fi
  if [[ "${BACKUP_COMPACTED}" =~ ^[yY]$ ]]; then
    backup_tenant_files "compacted"
  fi
  if [[ "${BACKUP_SCHEMAS_TIME_LOG}" =~ ^[yY]$ ]]; then
    log "Backing up tenant '${TENANT_NAME}' schemas time log files" "${LOG_TAG_INFO}" "y" "n"
    rsync -avqz "${TENANT_DIR}/" "${TENANT_BACKUP_DIR}/time-log" --exclude "compacted" --exclude "snapshots" \
      --exclude "parquet" --exclude "data"
  fi
  cp "${working_dir}/backup.parameters" "${TENANT_BACKUP_DIR}"
fi

find $BACKUPS_REPO -type d -empty -delete

if [[ ${successful_backup} = "true" ]]; then
  log "Backup operation finished successfully" "${LOG_TAG_INFO}" "y" "y"
else
  log "Backup operation failed" "${LOG_TAG_ERROR}" "y" "y"
fi
