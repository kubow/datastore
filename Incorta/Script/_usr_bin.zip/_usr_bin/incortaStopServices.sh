#! /usr/bin/sh
echo "Stopping the Incorta Notebook Add-On"
sudo systemctl stop incortanotebookaddon.service
sleep 4s
sudo systemctl status incortanotebookaddon.service -l
sleep 1s
echo "Stopping the Incorta Analytics Service"
sudo systemctl stop incortaanalytics.service
sleep 2s
sudo systemctl status incortaanalytics.service -l
echo "Stopping the Incorta Loader Service"
sudo systemctl stop incortaloader.service
sleep 2s
sudo systemctl status incortaloader.service -l
echo "Stopping the Incorta Spark Service"
sudo systemctl stop spark.service
sleep 1s
sudo systemctl status spark.service -l
echo "Stopping the Incorta CMC"
sudo systemctl stop incortacmc.service
sleep 2s
sudo systemctl status incortacmc.service -l
echo "Stopping the Incorta Agent"
sudo systemctl stop incortaagent.service
sleep 2s
sudo systemctl status incortaagent.service -l
echo "Stopping the Incorta Export Server"
sudo systemctl stop exportserver.service
sleep 2s
sudo systemctl status exportserver.service -l
echo "Stopping the Incorta Zookeeper"
sudo systemctl stop zookeeper.service
sleep 2s
sudo systemctl status zookeeper.service -l
sleep 2s
