#!/usr/bin/sh
echo "Starting the Incorta Zookeeper"
sudo systemctl start zookeeper.service
sleep 2s
sudo systemctl status zookeeper.service -l
sleep 1s
echo "Starting the Incorta Spark Service"
sudo systemctl start spark.service
sleep 2s
sudo systemctl status spark.service -l
sleep 1s
echo "Starting the Incorta Export Server"
sudo systemctl start exportserver.service
sleep 2s
sudo systemctl status exportserver.service -l
sleep 1s
echo "Starting the Incorta Agent"
sudo systemctl start incortaagent.service
sleep 2s
sudo systemctl status incortaagent.service -l
sleep 1s
echo "Starting the Incorta Loader Service"
sudo systemctl start incortaloader.service
sleep 4s
sudo systemctl status incortaloader.service -l
sleep 2s
echo "Starting the Incorta Analytics Service"
sudo systemctl start incortaanalytics.service
sleep 4s
sudo systemctl status incortaanalytics.service -l
sleep 1s
echo "Starting the Incorta Notebook Add-On"
sudo systemctl start incortanotebookaddon.service
sleep 4s
sudo systemctl status incortanotebookaddon.service -l
sleep 1s
echo "Starting the Incorta CMC"
sudo systemctl start incortacmc.service
sleep 1s
sudo systemctl status incortacmc.service -l
